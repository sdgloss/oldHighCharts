<!-- !!!! THIS ISSUE TRACKER IS FOR BUG REPORTS ONLY !!!! -->

<!-- If you have general questions, or need help, please reach out to us via -->
<!-- our other support channels: https://www.highcharts.com/support -->
<!-- IF YOUR POST DOES NOT FIT THE BELOW TEMPLATE, PLEASE USE THE LINK ABOVE! -->

<!-- We also can't provide in-depth support specific to your server/net config. -->

#### Expected behaviour


#### Actual behaviour
<!-- screenshots welcome! -->

#### Reproduction steps
<!-- Please describe how to reproduce the issue. --> 
<!-- If you can, please include a curl fetch that demonstrates the issue, e.g. -->
<!-- curl -H "Content-Type: application/json" -X POST -d '{"infile":{ <CHART OPTIONS HERE> }' 127.0.0.1:7801 -o mychart.png -->

